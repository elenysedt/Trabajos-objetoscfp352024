package centro35.ele.consultoriomedicoele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultoriomedicoeleApplicationTests {

	@Test
	void contextLoads() {
	}

}
