-- Active: 1715892049383@@127.0.0.1@3306
-- /Users/elenys/curso-cfp-java/objetos/2024CFP35ObjetosNoche/ConcesionariaEle/data/dataele.db     recuerda colocar localhost
-- DDL Data Definition Language (Lenguaje de Definición de Datos)
-- Definimos las estructuras de datos (Tablas)
select sqlite_version();

drop table if exists vehiculos;

create table vehiculos(
    id integer not null,
    marca text check(length(marca)>=3 and length(marca)<=50) not null,
    modelo text check(length(modelo)>=3 and length(modelo)<=50) not null,
    tipo text check(tipo in('AUTO','MOTO')) not null,
    puertas integer check(puertas>=0 and puertas<=5) null,
    cilindrada integer check(cilindrada>=100 and cilindrada<=250) null,
    precio REAL CHECK (precio >= 0) not null,
    primary key(id)
);