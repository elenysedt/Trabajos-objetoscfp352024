SELECT *
FROM vehiculos
WHERE tipo = 'AUTO';


SELECT *
FROM vehiculos
WHERE tipo = 'MOTO';

SELECT *
FROM vehiculos
WHERE marca = 'Honda';