-- DML Data Manipulation Language (Lenguaje de Manipulación de Datos)
-- Inserto Registros del ejercicio

INSERT INTO vehiculos (id, marca, modelo, tipo, puertas, cilindrada, precio)
VALUES
    (1, 'Peugeot', '206', 'AUTO', 4, NULL, 200000.0),
    (2, 'Honda', 'Titan', 'MOTO', NULL, 125, 60000.0),
    (3, 'Peugeot', '208', 'AUTO', 5, NULL, 250000.0),
    (4, 'Yamaha', 'YBR', 'MOTO', NULL, 160, 80500.5);

select * from vehiculos;