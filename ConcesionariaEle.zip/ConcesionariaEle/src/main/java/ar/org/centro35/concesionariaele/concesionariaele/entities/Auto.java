package ar.org.centro35.concesionariaele.concesionariaele.entities;

public class Auto extends Vehiculos {
    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    public int getPuertas() {
        return puertas;
    }

    @Override
    public String getTipo() {
        return "AUTO";
    }

    @Override
    public String toString() {
        return "Marca: " + marca + " // Modelo: " + modelo + " // Puertas: " + puertas + " // Precio: $"
                + String.format("%,.2f", precio);
    }
}
