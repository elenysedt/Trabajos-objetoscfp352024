package ar.org.centro35.concesionariaele.concesionariaele.test;

import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import ar.org.centro35.concesionariaele.concesionariaele.entities.Vehiculos;
import ar.org.centro35.concesionariaele.concesionariaele.repositories.VehiculosRepo;

public class TestConcesionariaEle {
    public static void main(String[] args) {
        VehiculosRepo vehiculosRepo = new VehiculosRepo();

        List<Vehiculos> vehiculos;
        try {
            vehiculos = vehiculosRepo.getAllVehiculos();
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }
        // Informacion
        vehiculos.forEach(System.out::println);

        System.out.println("=============================");

        // Vehiculo mas caro
        Optional<Vehiculos> vehiculoMasCaro = vehiculos.stream()
                .max(Comparator.comparingDouble(Vehiculos::getPrecio));
        vehiculoMasCaro.ifPresent(vehiculo -> 
                System.out.println("Vehículo más caro: " + vehiculo.getMarca() + " " + vehiculo.getModelo()));

        // Vehiculo mas barato
        Optional<Vehiculos> vehiculoMasBarato = vehiculos.stream()
                .min(Comparator.comparingDouble(Vehiculos::getPrecio));
        vehiculoMasBarato.ifPresent(vehiculo -> 
                System.out.println("Vehículo más barato: " + vehiculo.getMarca() + " " + vehiculo.getModelo()));

        // Vehiculo que contiene en el modelo la letra ‘Y’
        vehiculos
                .stream()
                .filter(vehiculo -> vehiculo.getModelo().contains("Y"))
                .forEach(vehiculo -> 
                System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: " + vehiculo.getMarca() + " "
                                + vehiculo.getModelo() + " $" + String.format("%,.2f", vehiculo.getPrecio())));

        System.out.println("=============================");

        // Vehiculos ordenados por precio de mayor a menor
        System.out.println("Vehiculos ordenados por precio de mayor a menor");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculos::getPrecio).reversed())
                .forEach(vehiculo -> System.out.println(vehiculo.getMarca() + " " + vehiculo.getModelo()));

        System.out.println("=============================");

        // Vehiculos ordenados por orden natural (marca, modelo, precio)
        System.out.println("Vehiculos ordenados por orden natural (marca, modelo, precio)");
        vehiculos
                .stream()
                .sorted(Comparator.comparing(Vehiculos::getMarca)
                        .thenComparing(Vehiculos::getModelo)
                        .thenComparing(Vehiculos::getPrecio))
                .forEach(vehiculo -> System.out.println(vehiculo.toString()));
    }
}
