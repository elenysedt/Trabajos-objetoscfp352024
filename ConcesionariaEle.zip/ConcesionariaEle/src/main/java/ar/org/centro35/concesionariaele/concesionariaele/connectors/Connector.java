package ar.org.centro35.concesionariaele.concesionariaele.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

    private static String url = "jdbc:sqlite:./data/dataele.db";

    private static Connection conn = null;

    private Connector() {
    }

    public static Connection getConnection() {
        try {
            conn = DriverManager.getConnection(url);
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }

}
