package ar.org.centro35.concesionariaele.concesionariaele.entities;

public class Moto extends Vehiculos {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    @Override
    public String getTipo() {
        return "MOTO";
    }

    @Override
    public String toString() {
        return "Marca: " + marca + " // Modelo: " + modelo + " // Cilindrada: " + cilindrada + "c // Precio: $"
                + String.format("%,.2f", precio);
    }
}