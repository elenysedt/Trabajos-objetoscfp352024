package ar.org.centro35.concesionariaele.concesionariaele.entities;

public abstract class Vehiculos implements Comparable<Vehiculos> {
    protected String marca;
    protected String modelo;
    protected double precio;

    public Vehiculos(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public abstract String getTipo();

    @Override
    public int compareTo(Vehiculos otro) {
        return Double.compare(otro.getPrecio(), this.precio);
    }

    @Override
    public abstract String toString();
}
