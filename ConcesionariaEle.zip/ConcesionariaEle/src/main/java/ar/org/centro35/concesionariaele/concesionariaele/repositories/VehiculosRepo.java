package ar.org.centro35.concesionariaele.concesionariaele.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro35.concesionariaele.concesionariaele.connectors.Connector;
import ar.org.centro35.concesionariaele.concesionariaele.entities.Vehiculos;
import ar.org.centro35.concesionariaele.concesionariaele.entities.Auto;
import ar.org.centro35.concesionariaele.concesionariaele.entities.Moto;

public class VehiculosRepo {
    private Connection conn = Connector.getConnection();

    public void save(Vehiculos vehiculos) {
        if (vehiculos == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into vehiculos (marca, modelo, tipo, puertas, cilindrada, precio) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, vehiculos.getMarca());
            ps.setString(2, vehiculos.getModelo());
            ps.setString(3, vehiculos.getTipo());
            ps.setDouble(4, vehiculos.getPrecio());
            if (vehiculos instanceof Auto) {
                ps.setInt(4, ((Auto) vehiculos).getPuertas());
                ps.setNull(5, java.sql.Types.INTEGER);
            } else if (vehiculos instanceof Moto) {
                ps.setNull(4, java.sql.Types.INTEGER);
                ps.setInt(5, ((Moto) vehiculos).getCilindrada());
            }
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Vehiculos> getAllVehiculos() throws SQLException {
        List<Vehiculos> vehiculos = new ArrayList<>();
        String query = "SELECT * FROM vehiculos";
        try (PreparedStatement ps = conn.prepareStatement(query);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String marca = rs.getString("marca");
                String modelo = rs.getString("modelo");
                Double precio = rs.getDouble("precio");
                String tipo = rs.getString("tipo");

                if (tipo.equals("AUTO")) {
                    int puertas = rs.getInt("puertas");
                    vehiculos.add(new Auto(marca, modelo, precio, puertas));
                } else if (tipo.equals("MOTO")) {
                    int cilindrada = rs.getInt("cilindrada");
                    vehiculos.add(new Moto(marca, modelo, precio, cilindrada));
                }
            }
        }
        return vehiculos;
    }

}
