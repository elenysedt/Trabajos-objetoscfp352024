package ar.org.centro35.concesionariaele.concesionariaele;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcesionariaEleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcesionariaEleApplication.class, args);
	}

}
