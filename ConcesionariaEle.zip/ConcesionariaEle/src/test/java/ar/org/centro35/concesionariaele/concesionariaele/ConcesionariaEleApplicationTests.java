package ar.org.centro35.concesionariaele.concesionariaele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcesionariaEleApplicationTests {

	@Test
	void contextLoads() {
	}

}
