package centro35.ele.consultoriomedicoele;

public @interface Test {

}
