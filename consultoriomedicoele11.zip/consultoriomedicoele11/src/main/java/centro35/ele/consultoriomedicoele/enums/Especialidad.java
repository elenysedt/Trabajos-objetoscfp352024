package centro35.ele.consultoriomedicoele.enums;

public enum Especialidad {

    CLINICA_MEDICA,
    CARDIOLOGIA,
    DERMATOLOGIA,
    NEUROLOGIA,
    GASTROENTEROLOGIA,
    OFTALMOLOGIA
}
