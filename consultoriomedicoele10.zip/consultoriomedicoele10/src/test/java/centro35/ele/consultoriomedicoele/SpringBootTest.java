package centro35.ele.consultoriomedicoele;

public @interface SpringBootTest {

}
