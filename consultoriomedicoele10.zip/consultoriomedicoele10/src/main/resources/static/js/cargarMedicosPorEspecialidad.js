function cargarMedicosPorEspecialidad() {
    const especialidad = document.getElementById('especialidad').value;
    const idMedicoSelect = document.getElementById('id_medico');
    
    fetch(`/medicosPorEspecialidad?especialidad=${especialidad}`)
        .then(response => response.json())
        .then(data => {
            // Limpiar opciones actuales
            idMedicoSelect.innerHTML = '<option value="" disabled selected>Seleccione un médico</option>';
            
            // Agregar nuevas opciones
            data.forEach(medico => {
                const option = document.createElement('option');
                option.value = medico.id;
                option.text = `${medico.apellido}, ${medico.nombre}`;
                idMedicoSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error:', error));
}
