-- Active: 1718765190059@@127.0.0.1@3306
SELECT sqlite_version();

drop Table if exists pacientes;

drop table if exists medicos;

drop table if exists turnos;

CREATE TABLE pacientes (
    id INTEGER NOT NULL,
    dni INTEGER CHECK (LENGTH(dni) >= 7 AND LENGTH(dni) <= 8) NOT NULL,
    nombre TEXT CHECK(LENGTH(nombre) >= 3 AND LENGTH(nombre) <= 35) NOT NULL,
    apellido TEXT CHECK(LENGTH(apellido) >= 3 AND LENGTH(apellido) <= 35) NOT NULL,
    edad INTEGER CHECK(edad >= 18 AND edad <= 120) NOT NULL,
    direccion TEXT CHECK(LENGTH(direccion) >= 3 AND LENGTH(direccion) <= 100) NOT NULL,
    nro_contacto VARCHAR (13) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE medicos (
    id INTEGER NOT NULL,
    dni INTEGER CHECK(LENGTH(dni) >= 7 AND LENGTH(dni) <= 8) NOT NULL,
    matricula VARCHAR(20) CHECK(length(matricula) >= 5 AND length(matricula) <= 20) NOT NULL,
    nombre TEXT CHECK(LENGTH(nombre) >= 3 AND LENGTH(nombre) <= 35) NOT NULL,
    apellido TEXT CHECK(LENGTH(apellido) >= 3 AND LENGTH(apellido) <= 35) NOT NULL,
    especialidad TEXT CHECK(especialidad IN ('CLINICA MEDICA', 'CARDIOLOGIA', 'DERMATOLOGIA', 'NEUROLOGIA', 'GASTROENTEROLOGIA', 'OFTALMOLOGIA')) NOT NULL,
    nro_contacto VARCHAR (13) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE turnos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_pacientes INTEGER NOT NULL,
    id_medicos INTEGER NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL CHECK (hora IN (
        '10:00', '10:30', '11:00', '11:30',
        '12:00', '12:30', '13:00', '13:30',
        '14:00', '14:30', '15:00', '15:30',
        '16:00', '16:30', '17:00', '17:30', '18:00'
    )),
    especialidad TEXT NOT NULL,
    estado TEXT CHECK (estado IN ('CONFIRMADO', 'PENDIENTE', 'CANCELADO')) NOT NULL,
    FOREIGN KEY (id_pacientes) REFERENCES pacientes(id),
    FOREIGN KEY (id_medicos) REFERENCES medicos(id),
    FOREIGN KEY (especialidad) REFERENCES medicos(especialidad)
);





