-- Active: 1718311379579@@127.0.0.1@3306
SELECT sqlite_version();

drop Table if exists pacientes;

drop table if exists medicos;

drop table if exists turnos;

drop table if exists historial_medico;

CREATE TABLE pacientes (
    id INTEGER NOT NULL,
    dni INTEGER CHECK (LENGTH(dni) >= 7 AND LENGTH(dni) <= 8) NOT NULL,
    nombre TEXT CHECK(LENGTH(nombre) >= 3 AND LENGTH(nombre) <= 35) NOT NULL,
    apellido TEXT CHECK(LENGTH(apellido) >= 3 AND LENGTH(apellido) <= 35) NOT NULL,
    edad INTEGER CHECK(edad >= 18 AND edad <= 120) NOT NULL,
    direccion TEXT CHECK(LENGTH(direccion) >= 3 AND LENGTH(direccion) <= 100) NOT NULL,
    nro_contacto TEXT CHECK(LENGTH(nro_contacto) = 10),
    PRIMARY KEY (id)
);

CREATE TABLE medicos (
    id INTEGER NOT NULL,
    dni INTEGER CHECK(LENGTH(dni) >= 7 AND LENGTH(dni) <= 8) NOT NULL,
    nombre TEXT CHECK(LENGTH(nombre) >= 3 AND LENGTH(nombre) <= 35) NOT NULL,
    apellido TEXT CHECK(LENGTH(apellido) >= 3 AND LENGTH(apellido) <= 35) NOT NULL,
    matricula TEXT CHECK(LENGTH(matricula) >= 5 AND LENGTH(matricula) <= 20) NOT NULL,
    especialidad TEXT CHECK(LENGTH(especialidad) >= 3 AND LENGTH(especialidad) <= 50),
    nro_contacto TEXT CHECK(LENGTH(nro_contacto) = 10),
    PRIMARY KEY (id)
);

CREATE TABLE citas (
    id INTEGER NOT NULL,
    id_paciente INTEGER NOT NULL,
    id_medico INTEGER NOT NULL,
    fecha_cita DATETIME NOT NULL,
    estado TEXT CHECK(LENGTH(estado) >= 3 AND LENGTH(estado) <= 50) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id),
    FOREIGN KEY (id_medico) REFERENCES medicos(id)
);

CREATE TABLE historial_medico (
    id INTEGER NOT NULL,
    id_paciente INTEGER NOT NULL,
    id_medico INTEGER NOT NULL,
    fecha_visita DATETIME NOT NULL,
    especialidad TEXT CHECK(LENGTH(especialidad) >= 3 AND LENGTH(especialidad) <= 50) NOT NULL,
    notas TEXT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id),
    FOREIGN KEY (id_medico) REFERENCES medicos(id)
);
