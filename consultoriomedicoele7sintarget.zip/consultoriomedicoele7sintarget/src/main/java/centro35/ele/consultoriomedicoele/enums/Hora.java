package centro35.ele.consultoriomedicoele.enums;

public enum Hora {
    H10_00,
    H10_30,
    H11_00,
    H11_30,
    H12_00,
    H12_30,
    H13_00,
    H13_30,
    H14_00,
    H14_30,
    H15_00,
    H15_30,
    H16_00,
    H16_30,
    H17_00,
    H17_30,
    H18_00

}
