package centro35.ele.consultoriomedicoele.controllers;


import centro35.ele.consultoriomedicoele.entities.Turno;
import centro35.ele.consultoriomedicoele.enums.Estado;
import centro35.ele.consultoriomedicoele.enums.Hora;
import centro35.ele.consultoriomedicoele.repositories.TurnoRepository;

public class TurnoController {
    
}
