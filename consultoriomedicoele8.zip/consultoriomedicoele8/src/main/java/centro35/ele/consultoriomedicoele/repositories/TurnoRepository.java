package centro35.ele.consultoriomedicoele.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import centro35.ele.consultoriomedicoele.connectors.Connector;
import centro35.ele.consultoriomedicoele.entities.Turno;
import centro35.ele.consultoriomedicoele.enums.Estado;
import centro35.ele.consultoriomedicoele.enums.Hora;

public class TurnoRepository {
    private Connection conn = Connector.getConnection();

    public void save(Turno turno) {
        if (turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into turnos (id_pacientes, id_medicos, fecha, hora, estado) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, turno.getId_pacientes());
            ps.setInt(2, turno.getId_medicos());
            ps.setString(3, turno.getFecha());
            ps.setString(4, turno.getHora().toString());
            ps.setString(5, turno.getEstado().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                turno.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Turno> getAll() {
        List<Turno> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from turnos")) {
            while (rs.next()) {
                list.add(new Turno(
                        rs.getInt("id"),
                        rs.getInt("id_pacientes"),
                        rs.getInt("id_medicos"),
                        rs.getString("fecha"),
                        Hora.valueOf(rs.getString("hora")),
                        Estado.valueOf(rs.getString("estado"))));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void remove(Turno turno) {
        if (turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from turnos where id=?")) {
            ps.setInt(1, turno.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Turno getById(int id) {
        return getAll()
                .stream()
                .filter(turno -> turno.getId() == id)
                .findAny()
                .orElse(new Turno());
    }

    public List<Turno> getLikeFecha(String fecha) {
        if (fecha == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(turno -> turno.getFecha().toLowerCase().contains(fecha.toLowerCase()))
                .toList();
    }

}
