package centro35.ele.consultoriomedicoele.enums;

public enum Estado {
    CONFIRMADO,
    PENDIENTE,
    CANCELADO
}
